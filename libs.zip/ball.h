class Ball{
private:
    int x;
    int y;
    int speed_x;
    int speed_y;
    int rad;
    int x_max;
    int y_max;
    int x_min;
    int y_min;
    COLORREF color;
public:
    Ball(int x,
        int y,
        int speed_x,
        int speed_y,
        int rad,
        COLORREF color
        ){
        this -> x = x;
        this -> y = y;
        this -> speed_x = speed_x;
        this -> speed_y = speed_y;
        this -> rad = rad;
        this -> color = color;
        x_max = 1300;//850
        y_max = 800;
        x_min = 600;//150
        y_min = 200;
    }

    void draw_ball(){
        txSetColor(color);
        txSetFillColor(color);
        txCircle(x,y,rad);
    }
    void move(){
        x=x+speed_x;
        y=y+speed_y;
    }
    void check_sides(int stick1_y,int stick2_y){
        if(x+speed_x >= x_max-rad && y+speed_y<=stick2_y+200+rad-2 && y+speed_y>=stick2_y-rad+2)/*�����*/{
            x=x+speed_x-2*(x+speed_x-(x_max-rad));
            speed_x=speed_x*-1;
        }
        else if(x+speed_x <= x_min+rad && y <=stick1_y+200+rad && y  >=stick1_y-rad)/*����*/{
            x=x+speed_x+2*((x_min+rad)-(x+speed_x));
            speed_x=speed_x*-1;
        }
        if(y+speed_y >= y_max-rad)/*���*/{
            y=y+speed_y-2*(y+speed_y-(y_max-rad));
            speed_y=speed_y*-1;
        }
        else if(y+speed_y <= y_min+rad)/*����*/{
            //cout<<"y"<<y<<"speed_y"<<speed_y ;
            y=y+speed_y+2*(y_min+rad-(y+speed_y));
            speed_y=speed_y*-1;
            cout<<"y"<<y<<"speed_y"<<speed_y ;
        }

    }

    void check_box_sides(){
        if(x+speed_x >= x_max-rad )/*�����*/{
            x=x+speed_x-2*(x+speed_x-(x_max-rad));
            speed_x=speed_x*-1;
        }
        else if(x+speed_x <= x_min+rad)/*����*/{
            x=x+speed_x+2*((x_min+rad)-(x+speed_x));
            speed_x=speed_x*-1;
        }
        if(y+speed_y >= y_max-rad)/*���*/{
            y=y+speed_y-2*(y+speed_y-(700-rad));
            speed_y=speed_y*-1;
        }
        else if(y+speed_y <= y_min+rad)/*����*/{
            cout<<"y"<<y<<"speed_y"<<speed_y ;
            y=y+speed_y+2*(y_min+rad-(y+speed_y));
            speed_y=speed_y*-1;
            cout<<"y"<<y<<"speed_y"<<speed_y ;
        }
    }

    int get_x(){
        return x;
    }
    int get_y(){
        return y;
    }
    int get_speed_x(){
        return speed_x;
    }
    int get_speed_y(){
        return speed_y;
    }
    int get_rad(){
        return rad;
    }

    void set_x(int x){
        this->x = x;
    }
    void set_y(int y){
        this->y = y;
    }
    void set_speed_x(int speed_x){
        this->speed_x = speed_x;
    }
    void set_speed_y(int speed_y){
        this->speed_y = speed_y;
    }


};
