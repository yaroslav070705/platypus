#ifndef Base_Block
#include "base_block.h"
#endif // !base

class MovingBlock : public BaseBlock{
private:
	int speed;
public:
	MovingBlock(int x, int y, int speed, HDC pic) : BaseBlock(x, y, pic) {}
	void move(int side);
};

MovingBlock::MovingBlock(int x, int y, int speed, HDC pic) : BaseBlock(x, y, pic) {
	this->speed = speed;
}

void MovingBlock::move(int side) {
	if (side == 1) {
		x += speed;
	}
	else {
		x -= speed;
	}
}