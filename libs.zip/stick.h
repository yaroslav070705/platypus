class Stick{
public:
    int x;
    int y;
    int height;
    int speed;
    bool move_up_flag = true;
    bool move_down_flag = true;
    int y_max;
    int y_min;

    Stick(int x,
          int y,
          int height,
          int speed
          ){
        this -> x = x;
        this -> y = y;
        this -> height = height;
        this -> speed = speed;
        y_max = 800;
        y_min = 200;
    }

    void move_up(){
        y = y - speed;
        move_down_flag = true;
    }

    void move_down(){
        y = y + speed;
        move_up_flag = true;
    }

    void draw_stick(){
        txSetColor(TX_WHITE,5);
        txLine(x,y,x,y+height);
    }

    void check_sides(){
        if(y+height+speed >= y_max){
            move_down_flag = false;
        }
        else if(y-speed <= y_min){
            move_up_flag = false;
        }
    }
};

class EnemyStick : public Stick{
public:

    EnemyStick(int x,int y,int height,int speed):Stick(x,y,height,speed)
    {}
};
