#ifndef Main_Hero
#include "main_hero.h"
#endif // !Main_Hero
using namespace std;

class Fugu : public MainHero {
public:

    Fugu(int x, int y) : MainHero(height, width) {
        this->x = x;
        this->y = y;
        speed = 10;
        jump_speed = 30;
        height = 180;
        width = 111;
        pic = txLoadImage("images\\fugu_spritesheet.bmp");
        gravity = true;
    }
    void move();
};


void Fugu::move() {
    if (GetAsyncKeyState(VK_SPACE) && !jump) {
        jump = true;
        now_jump_height = y - jump_height;
        j_pic = 8;
    }
    if (jump) {
        if (y >= now_jump_height) {
            y -= jump_speed;
        }
        else {
            jump = false;
        }
    }
    if (GetAsyncKeyState(68)) { //right
        i_pic = 0;
        if (!jump) {
            if (j_pic < 7) {
                j_pic += 1;
            }
            else {
                j_pic = 0;
            }
        }
        x += speed;
    }
    else if (GetAsyncKeyState(65)) {    //left
        i_pic = 1;
        if (!jump) {
            if (j_pic < 7) {
                j_pic += 1;
            }
            else {
                j_pic = 0;
            }
        }
        x -= speed;
    }
    else if (!jump) {
        i_pic = 0;
        j_pic = 0;
    }
    if (gravity == true) {
        y = y + 10;
    }
}
