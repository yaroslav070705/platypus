#include <iostream>

using namespace std;

class Korornovirus(){





}
