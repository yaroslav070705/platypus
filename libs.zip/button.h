#include <iostream>
#include "string"
using namespace std;

class Button{

public:
    int x;
    int y;
    int height;
    int width;
    bool state ;
    double font_height;
    void(*command)();
    const char  *text;
    const char *font;
    COLORREF bg;
    COLORREF tg;
    bool mouse_on = false;
    Button(int x,
            int y,
            void(*command)(),
            const char  *text = "",
            const char *font = "",
            double font_height = 10,
            int height = 40,
            int width = 100,
            COLORREF bg= TX_BLACK,
            COLORREF tg = TX_BLACK,
            bool state = true )
    {
        this -> x = x;
        this -> y = y;
        this -> height = height;
        this -> width = width;
        this -> font_height = font_height;
        this -> command = command;
        this -> text = text;
        this -> font = font;
        this -> bg = bg;
        this -> tg = tg;
        this->state = state;
    }
    void check_mouse_on(){
        if(txMouseY() >= y && txMouseY() <=y+height && txMouseX() >=x && txMouseX() <=x+width){
            mouse_on = true;
        }
        else{
            mouse_on = false;
        }
    }
    bool check_click(){
        if(txMouseButtons() & 1 && mouse_on){
            return true;

        }
        return false;
    }
    void do_comand() {
        (*command)();

    }
    void place(){
        //txSetFillColor(bg);
        txSelectFont(font,font_height);
        if(mouse_on == false){
            txSetColor(tg);
            txSetFillColor(bg);
            txRectangle(x,y,x+width,y+height);
            txSetColor(tg);
            txDrawText(x+1,y+1,x+width-1,y+height-1,text);
        }
        if(mouse_on == true){
            txSetColor(TX_GRAY,3);
            txSetFillColor(bg);
            txRectangle(x,y,x+width,y+height);
            txSetColor(tg);
            txDrawText(x+1,y+1,x+width-1,y+height-1,text);
        }

    }
    
    bool get_state() {
        return state;
    }

    void set_state(bool state) {
        this->state = state;
    }

    void set_function(void(*command)()) {
        this->command = command;
    }
    
};
