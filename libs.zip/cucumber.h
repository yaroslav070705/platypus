#include <iostream>

using namespace std;

class Cucumber{
public:
    int x = 500;
    int y = 200;
    int scale = 1;
    int position_legs = 0;
    int eye = 0;
    void draw_cucumber(){
        //����
        txSetColor(TX_BLACK);
        txSetFillColor(TX_BLACK);
        txRectangle(x+(110)*scale,y+(30)*scale,x+(120)*scale,y+(50)*scale);
        txRectangle(x+(120)*scale,y+(20)*scale,x+(140)*scale,y+(30)*scale);
        txRectangle(x+(130)*scale,y+(10)*scale,x+(160)*scale,y+(20)*scale);
        txRectangle(x+(150)*scale,y+(0)*scale,x+(180)*scale,y+(10)*scale);
        txRectangle(x+(170)*scale,y+(10)*scale,x+(200)*scale,y+(20)*scale);
        txRectangle(x+(190)*scale,y+(20)*scale,x+(210)*scale,y+(30)*scale);
        txRectangle(x+(200)*scale,y+(30)*scale,x+(230)*scale,y+(40)*scale);
        txRectangle(x+(220)*scale,y+(40)*scale,x+(250)*scale,y+(50)*scale);
        txRectangle(x+(240)*scale,y+(50)*scale,x+(260)*scale,y+(60)*scale);
        txRectangle(x+(250)*scale,y+(60)*scale,x+(280)*scale,y+(70)*scale);
        txRectangle(x+(270)*scale,y+(70)*scale,x+(300)*scale,y+(80)*scale);
        txRectangle(x+(290)*scale,y+(80)*scale,x+(330)*scale,y+(90)*scale);
        txRectangle(x+(320)*scale,y+(90)*scale,x+(340)*scale,y+(100)*scale);
        txRectangle(x+(340)*scale,y+(100)*scale,x+(360)*scale,y+(110)*scale);
        txRectangle(x+(350)*scale,y+(110)*scale,x+(370)*scale,y+(120)*scale);
        txRectangle(x+(370)*scale,y+(120)*scale,x+(380)*scale,y+(130)*scale);
        txRectangle(x+(380)*scale,y+(130)*scale,x+(390)*scale,y+(170)*scale);
        txRectangle(x+(370)*scale,y+(170)*scale,x+(390)*scale,y+(180)*scale);
        txRectangle(x+(370)*scale,y+(180)*scale,x+(380)*scale,y+(190)*scale);
        txRectangle(x+(350)*scale,y+(190)*scale,x+(380)*scale,y+(200)*scale);
        txRectangle(x+(320)*scale,y+(200)*scale,x+(360)*scale,y+(210)*scale);
        txRectangle(x+(290)*scale,y+(190)*scale,x+(320)*scale,y+(200)*scale);
        txRectangle(x+(260)*scale,y+(180)*scale,x+(290)*scale,y+(190)*scale);
        txRectangle(x+(230)*scale,y+(170)*scale,x+(260)*scale,y+(180)*scale);
        txRectangle(x+(210)*scale,y+(160)*scale,x+(240)*scale,y+(170)*scale);
        txRectangle(x+(200)*scale,y+(150)*scale,x+(230)*scale,y+(160)*scale);
        txRectangle(x+(190)*scale,y+(140)*scale,x+(210)*scale,y+(150)*scale);
        txRectangle(x+(170)*scale,y+(130)*scale,x+(190)*scale,y+(140)*scale);
        txRectangle(x+(160)*scale,y+(120)*scale,x+(170)*scale,y+(130)*scale);
        txRectangle(x+(140)*scale,y+(110)*scale,x+(160)*scale,y+(120)*scale);
        txRectangle(x+(130)*scale,y+(90)*scale,x+(140)*scale,y+(110)*scale);
        txRectangle(x+(120)*scale,y+(80)*scale,x+(130)*scale,y+(100)*scale);
        txRectangle(x+(130)*scale,y+(70)*scale,x+(160)*scale,y+(80)*scale);
        txRectangle(x+(160)*scale,y+(50)*scale,x+(170)*scale,y+(70)*scale);
        txRectangle(x+(140)*scale,y+(40)*scale,x+(160)*scale,y+(50)*scale);
        txRectangle(x+(120)*scale,y+(50)*scale,x+(140)*scale,y+(60)*scale);
        txSetFillColor(RGB(13,105,26));
        txFloodFill(x+(220)*scale,y+(90)*scale);

        txSetFillColor(RGB(2,59,27));
        txSetColor(RGB(2,59,27));
        txRectangle(x+(120)*scale,y+(40)*scale,x+(130)*scale,y+(50)*scale);
        txRectangle(x+(150)*scale,y+(90)*scale,x+(160)*scale,y+(100)*scale);
        txRectangle(x+(180)*scale,y+(40)*scale,x+(190)*scale,y+(50)*scale);
        txRectangle(x+(180)*scale,y+(100)*scale,x+(190)*scale,y+(110)*scale);
        txRectangle(x+(200)*scale,y+(70)*scale,x+(210)*scale,y+(80)*scale);
        txRectangle(x+(240)*scale,y+(90)*scale,x+(250)*scale,y+(100)*scale);
        txRectangle(x+(220)*scale,y+(120)*scale,x+(230)*scale,y+(130)*scale);
        txRectangle(x+(250)*scale,y+(150)*scale,x+(260)*scale,y+(160)*scale);
        txRectangle(x+(280)*scale,y+(110)*scale,x+(290)*scale,y+(120)*scale);
        txRectangle(x+(310)*scale,y+(150)*scale,x+(320)*scale,y+(160)*scale);
        txRectangle(x+(340)*scale,y+(180)*scale,x+(350)*scale,y+(190)*scale);
        txRectangle(x+(360)*scale,y+(130)*scale,x+(370)*scale,y+(140)*scale);

        //�����
        txSetFillColor(RGB(252,219,50));
        txSetColor(RGB(252,219,50));
        txRectangle(x+(380)*scale,y+(180)*scale,x+(400)*scale,y+(190)*scale);
        txRectangle(x+(390)*scale,y+(190)*scale,x+(410)*scale,y+(200)*scale);

        //���� � ����
        if(eye == 0){
            txSetFillColor(TX_BLACK);
            txSetColor(TX_BLACK);
        }
        else{
            txSetFillColor(RGB(255,3,230));
            txSetColor(RGB(255,3,230));
            txRectangle(x+(140)*scale,y+(50)*scale,x+(160)*scale,y+(60)*scale);
            txRectangle(x+(70)*scale,y+(60)*scale,x+(160)*scale,y+(70)*scale);
            txRectangle(x+(80)*scale,y+(50)*scale,x+(90)*scale,y+(80)*scale);

            txSetFillColor(TX_RED);
            txSetColor(TX_RED);

        }
        txRectangle(x+(160)*scale,y+(20)*scale,x+(170)*scale,y+(30)*scale);

        //����
        txSetFillColor(RGB(19,33,25));
        txSetColor(RGB(19,33,25));
        if(position_legs == 0){
            txRectangle(x+(290)*scale,y+(190)*scale,x+(300)*scale,y+(240)*scale);
            txRectangle(x+(300)*scale,y+(230)*scale,x+(320)*scale,y+(240)*scale);
            txRectangle(x+(170)*scale,y+(150)*scale,x+(180)*scale,y+(170)*scale);
            txRectangle(x+(170)*scale,y+(170)*scale,x+(230)*scale,y+(180)*scale);
        }
        else{
            txRectangle(x+(290)*scale,y+(190)*scale,x+(340)*scale,y+(200)*scale);
            txRectangle(x+(330)*scale,y+(170)*scale,x+(340)*scale,y+(190)*scale);
            txRectangle(x+(200)*scale,y+(230)*scale,x+(230)*scale,y+(240)*scale);
            txRectangle(x+(220)*scale,y+(170)*scale,x+(230)*scale,y+(240)*scale);
        }

        //����
        txSetFillColor(TX_BLACK);
        txSetColor(TX_BLACK);
        /////�������
        txRectangle(x+(60)*scale,y+(100)*scale,x+(130)*scale,y+(110)*scale);
        txRectangle(x+(40)*scale,y+(90)*scale,x+(60)*scale,y+(120)*scale);
        txRectangle(x+(20)*scale,y+(100)*scale,x+(40)*scale,y+(110)*scale);
        txRectangle(x+(30)*scale,y+(120)*scale,x+(50)*scale,y+(130)*scale);
        txRectangle(x+(10)*scale,y+(80)*scale,x+(50)*scale,y+(90)*scale);
        txRectangle(x+(0)*scale,y+(110)*scale,x+(30)*scale,y+(120)*scale);
        txRectangle(x+(10)*scale,y+(130)*scale,x+(40)*scale,y+(140)*scale);
        /////������
        txRectangle(x+(120)*scale,y+(140)*scale,x+(190)*scale,y+(150)*scale);
        txRectangle(x+(100)*scale,y+(130)*scale,x+(120)*scale,y+(160)*scale);
        txRectangle(x+(80)*scale,y+(120)*scale,x+(110)*scale,y+(130)*scale);
        txRectangle(x+(70)*scale,y+(140)*scale,x+(100)*scale,y+(150)*scale);
        txRectangle(x+(80)*scale,y+(160)*scale,x+(110)*scale,y+(170)*scale);



    }
};
