#include <iostream>
#include <vector>
using namespace std;

class MainHeroo {
protected:
    int legs = 0;
    int rotation = -1;
    int eyes = 0;
    double scale = 0.5;
    int speed = settings.hero_speed;
    int x = 500;
    int y = 200;
    int height = 0;
    int width = 0;
    bool fall_down = true;
    Settings settings;
public:
    MainHeroo(int height, int width, int way) {
        vector <int> leftbottom = { x + way,y };
        vector <int> lefttop = { x + way,y + height };
        vector <int> rightbottom = { x + way + width,y };
        vector <int> righttop = { x + way + width,y + height };
    }
    void update(int new_x, int new_y) {
        if (fall_down == true) {
            new_y = y + 10;
        }
        if (new_x == x) {
            legs = 0;
        }

        else {
            if (legs == 0) {
                legs = 1;
            }
            else if (legs == 1) {
                legs = 2;
            }

            else {
                legs = 1;
            }
        }

        x = new_x;
        y = new_y;
    }

    int get_x() {
        return x;
    }
    int get_y() {
        return y;
    }
    int get_legs() {
        return legs;
    }
    int get_rotation() {
        return rotation;
    }
    int get_eyes() {
        return eyes;
    }
    double get_scale() {
        return scale;
    }
    int get_speed() {
        return speed;
    }
    int get_height() {
        return height;
    }
    int get_width() {
        return width;
    }
    bool get_fall_down() {
        return fall_down;
    }

    void set_x(int x) {
        this-> x = x;
    }
    void set_y(int y) {
        this-> y = y;
    }
    void set_legs(int legs) {
        this-> legs =legs;
    }
    void set_rotation(int rotation) {
        this-> rotation = rotation;
    }
    void set_eyes(int eyes) {
        this-> eyes = eyes ;
    }
    void set_scale(double scale) {
        this-> scale = scale;
    }
    void set_speed(int speed) {
        this-> speed = speed;
    }
    void set_height(int height) {
        this-> height = height;
    }
    void set_width(int width) {
        this-> width = width;
    }
    void set_fall_down(bool fall_down) {
        this-> fall_down = fall_down;
    }


};

class Platypuss :  public MainHeroo{
public:
        int way = 10 * scale;

        Platypuss() : MainHeroo(height, width,way){
            height = 200 *scale;
            width = 80 * scale;
        }

        void draw_platypus(){
            //����

            if (legs == 0){
                txSetColor(RGB(249,168,37));
                txSetFillColor(RGB(249,168,37));
                txRectangle(x+(20)*scale,y+(20)*scale*rotation,x+(50)*scale,(y));
                txRectangle(x+(70)*scale,y+(20)*scale*rotation,x+(100)*scale,(y));

                txSetFillColor(RGB(181,122,50));
                txSetColor(RGB(181,122,50));
                txRectangle(x+(40)*scale,y+(10)*scale*rotation,x+(50)*scale,y+(0)*scale*rotation);
                txRectangle(x+(90)*scale,y+(10)*scale*rotation,x+(100)*scale,y+(0)*scale*rotation);

                txSetFillColor(RGB(196,142,67));
                txSetColor(RGB(196,142,67))*scale;
                txRectangle(x+(40)*scale,y+(20)*scale*rotation,x+(50)*scale,y+(10)*scale*rotation);
                txRectangle(x+(90)*scale,y+(20)*scale*rotation,x+(100)*scale,y+(10)*scale*rotation);

                txSetColor(TX_BLACK);
                txSetFillColor(TX_BLACK);
                txRectangle(x+(20)*scale,y+(50)*scale*rotation,x+(30)*scale,y+(20)*scale*rotation);
                txRectangle(x+(70)*scale,y+(40)*scale*rotation,x+(80)*scale,y+(20)*scale*rotation);

            }
            else if (legs == 1){//������� ������ ����
                txSetColor(RGB(249,168,37));
                txSetFillColor(RGB(249,168,37));
                txRectangle(x+(20)*scale,y+(20)*scale*rotation,x+(50)*scale,(y));
                txRectangle(x+(70)*scale,y+(35)*scale*rotation,x+(100)*scale,y+(15)*scale*rotation);

                txSetFillColor(RGB(181,122,50));
                txSetColor(RGB(181,122,50));
                txRectangle(x+(40)*scale,y+(10)*scale*rotation,x+(50)*scale,y+(0)*scale*rotation);
                txRectangle(x+(90)*scale,y+(15)*scale*rotation,x+(100)*scale,y+(25)*scale*rotation);

                txSetFillColor(RGB(196,142,67));
                txSetColor(RGB(196,142,67));
                txRectangle(x+(40)*scale,y+(20)*scale*rotation,x+(50)*scale,y+(10)*scale*rotation);
                txRectangle(x+(90)*scale,y+(25)*scale*rotation,x+(100)*scale,y+(35)*scale*rotation);

                txSetColor(TX_BLACK);
                txSetFillColor(TX_BLACK);
                txRectangle(x+(20)*scale,y+(50)*scale*rotation,x+(30)*scale,y+(20)*scale*rotation);
                txRectangle(x+(70)*scale,y+(40)*scale*rotation,x+(80)*scale,y+(35)*scale*rotation);

            }
            else if (legs == 2){//������� ����� ����
                txSetColor(TX_BLACK);
                txSetFillColor(TX_BLACK);
                txRectangle(x+(70)*scale,y+(40)*scale*rotation,x+(80)*scale,y+(20)*scale*rotation);
                txRectangle(x+(20)*scale,y+(50)*scale*rotation,x+(30)*scale,y+(35)*scale*rotation);

                txSetColor(RGB(249,168,37));
                txSetFillColor(RGB(249,168,37));
                txRectangle(x+(20)*scale,y+(35)*scale*rotation,x+(50)*scale,y+(15)*scale*rotation);
                txRectangle(x+(70)*scale,y+(20)*scale*rotation,x+(100)*scale,(y));

                txSetFillColor(RGB(181,122,50));
                txSetColor(RGB(181,122,50));
                txRectangle(x+(40)*scale,y+(15)*scale*rotation,x+(50)*scale,y+(25)*scale*rotation);
                txRectangle(x+(90)*scale,y+(10)*scale*rotation,x+(100)*scale,y+(0)*scale*rotation);

                txSetFillColor(RGB(196,142,67));
                txSetColor(RGB(196,142,67));
                txRectangle(x+(40)*scale,y+(25)*scale*rotation,x+(50)*scale,y+(35)*scale*rotation);
                txRectangle(x+(90)*scale,y+(20)*scale*rotation,x+(100)*scale,y+(10)*scale*rotation);

            }

            //����

            txSetColor(TX_BLACK);
            txSetFillColor(TX_BLACK);
            txRectangle(x+(30)*scale,y+(40)*scale*rotation,x+(70)*scale,y+(30)*scale*rotation);
            txRectangle(x+(80)*scale,y+(50)*scale*rotation,x+(90)*scale,y+(40)*scale*rotation);
            txRectangle(x+(10)*scale,y+(110)*scale*rotation,x+(20)*scale,y+(50)*scale*rotation);
            txRectangle(x+(90)*scale,y+(110)*scale*rotation,x+(100)*scale,y+(50)*scale*rotation);
            txRectangle(x+(20)*scale,y+(120)*scale*rotation,x+(30)*scale,y+(110)*scale*rotation);
            txRectangle(x+(80)*scale,y+(120)*scale*rotation,x+(90)*scale,y+(110)*scale*rotation);
            txRectangle(x+(30)*scale,y+(130)*scale*rotation,x+(40)*scale,y+(120)*scale*rotation);
            txRectangle(x+(20)*scale,y+(140)*scale*rotation,x+(30)*scale,y+(130)*scale*rotation);
            txRectangle(x+(70)*scale,y+(140)*scale*rotation,x+(80)*scale,y+(120)*scale*rotation);
            txRectangle(x+(10)*scale,y+(180)*scale*rotation,x+(20)*scale,y+(140)*scale*rotation);
            txRectangle(x+(20)*scale,y+(190)*scale*rotation,x+(30)*scale,y+(180)*scale*rotation);
            txRectangle(x+(30)*scale,y+(200)*scale*rotation,x+(100)*scale,y+(190)*scale*rotation);
            txRectangle(x+(100)*scale,y+(190)*scale*rotation,x+(110)*scale,y+(180)*scale*rotation);
            txRectangle(x+(110)*scale,y+(180)*scale*rotation,x+(150)*scale,y+(170)*scale*rotation);
            txRectangle(x+(150)*scale,y+(170)*scale*rotation,x+(160)*scale,y+(140)*scale*rotation);
            txRectangle(x+(90)*scale,y+(140)*scale*rotation,x+(150)*scale,y+(130)*scale*rotation);
            txRectangle(x+(80)*scale,y+(150)*scale*rotation,x+(90)*scale,y+(140)*scale*rotation);
            txRectangle(x+(90)*scale,y+(160)*scale*rotation,x+(100)*scale,y+(150)*scale*rotation);
            txRectangle(x+(100)*scale,y+(170)*scale*rotation,x+(110)*scale,y+(160)*scale*rotation);

            txSetFillColor(RGB(109,76,65));
            txFloodFill (x+(40)*scale,y+(100)*scale*rotation);

            //�����

            txSetColor(TX_BLACK);
            txSetFillColor(TX_BLACK);
            if (eyes == 0){
                txRectangle(x+(60)*scale,y+(180)*scale*rotation,x+(80)*scale,y+(160)*scale*rotation);
                txSetColor(TX_WHITE);
                txSetFillColor(TX_WHITE);
                txRectangle(x+(70)*scale,y+(170)*scale*rotation,x+(80)*scale,y+(160)*scale*rotation);
            }
            else{
                txSetColor(TX_RED);
                txSetFillColor(TX_RED);
                txRectangle(x+(60)*scale,y+(180)*scale*rotation,x+(80)*scale,y+(160)*scale*rotation);
            }

            //����

            txSetFillColor(RGB(239,108,0));
            txFloodFill (x+(130)*scale,y+(150)*scale*rotation);


            //����
            txSetColor(TX_BLACK);
            txSetFillColor(TX_BLACK);
            txRectangle(x+(50)*scale,y+(110)*scale*rotation,x+(60)*scale,y+(50)*scale*rotation);
            txRectangle(x+(40)*scale,y+(70)*scale*rotation,x+(70)*scale,y+(60)*scale*rotation);

        }
};
