#include <iostream>
using namespace std;

class Putin{
public:
    void draw_putin(int x,int y,double scale,int legs,int eyes){
        //������
        txSetFillColor(TX_BLACK);
        txSetColor(TX_BLACK);
        txRectangle(x+(0)*scale,y+(0)*scale,x+(20)*scale,y+(10)*scale);
        txRectangle(x+(0)*scale,y+(10)*scale,x+(10)*scale,y+(50)*scale);
        txRectangle(x+(10)*scale,y+(50)*scale,x+(20)*scale,y+(70)*scale);
        txRectangle(x+(20)*scale,y+(10)*scale,x+(30)*scale,y+(50)*scale);
        txRectangle(x+(30)*scale,y+(50)*scale,x+(40)*scale,y+(70)*scale);
        txRectangle(x+(20)*scale,y+(70)*scale,x+(40)*scale,y+(80)*scale);
        txRectangle(x+(40)*scale,y+(80)*scale,x+(50)*scale,y+(110)*scale);
        txRectangle(x+(50)*scale,y+(110)*scale,x+(60)*scale,y+(120)*scale);
        txRectangle(x+(60)*scale,y+(120)*scale,x+(80)*scale,y+(130)*scale);
        txRectangle(x+(70)*scale,y+(130)*scale,x+(100)*scale,y+(140)*scale);
        txRectangle(x+(100)*scale,y+(140)*scale,x+(160)*scale,y+(150)*scale);
        txRectangle(x+(160)*scale,y+(130)*scale,x+(190)*scale,y+(140)*scale);
        txRectangle(x+(180)*scale,y+(120)*scale,x+(200)*scale,y+(130)*scale);
        txRectangle(x+(200)*scale,y+(110)*scale,x+(210)*scale,y+(120)*scale);
        txRectangle(x+(210)*scale,y+(80)*scale,x+(220)*scale,y+(110)*scale);
        txRectangle(x+(220)*scale,y+(70)*scale,x+(240)*scale,y+(80)*scale);
        txRectangle(x+(220)*scale,y+(50)*scale,x+(230)*scale,y+(70)*scale);
        txRectangle(x+(230)*scale,y+(10)*scale,x+(240)*scale,y+(50)*scale);
        txRectangle(x+(240)*scale,y+(0)*scale,x+(260)*scale,y+(10)*scale);
        txRectangle(x+(250)*scale,y+(10)*scale,x+(260)*scale,y+(50)*scale);
        txRectangle(x+(240)*scale,y+(50)*scale,x+(250)*scale,y+(70)*scale);
        txSetFillColor(RGB(255,172,64));
        txSetColor(RGB(255,172,64));
        txRectangle(x+(10)*scale,y+(0)*scale,x+(20)*scale,y+(-50)*scale);
        txRectangle(x+(20)*scale,y+(-50)*scale,x+(30)*scale,y+(-70)*scale);
        txRectangle(x+(30)*scale,y+(-70)*scale,x+(40)*scale,y+(-90)*scale);
        txRectangle(x+(40)*scale,y+(-90)*scale,x+(50)*scale,y+(-100)*scale);
        txRectangle(x+(50)*scale,y+(-100)*scale,x+(70)*scale,y+(-110)*scale);
        txRectangle(x+(70)*scale,y+(-110)*scale,x+(90)*scale,y+(-120)*scale);
        txRectangle(x+(90)*scale,y+(-120)*scale,x+(180)*scale,y+(-130)*scale);
        txRectangle(x+(180)*scale,y+(-120)*scale,x+(200)*scale,y+(-110)*scale);
        txRectangle(x+(200)*scale,y+(-110)*scale,x+(220)*scale,y+(-100)*scale);
        txRectangle(x+(220)*scale,y+(-100)*scale,x+(230)*scale,y+(-90)*scale);
        txRectangle(x+(230)*scale,y+(-90)*scale,x+(240)*scale,y+(-70)*scale);
        txRectangle(x+(240)*scale,y+(-70)*scale,x+(250)*scale,y+(-50)*scale);
        txRectangle(x+(250)*scale,y+(-50)*scale,x+(260)*scale,y+(0)*scale);
        txRectangle(x+(30)*scale,y+(10)*scale,x+(40)*scale,y+(-40)*scale);
        txRectangle(x+(40)*scale,y+(-40)*scale,x+(50)*scale,y+(-70)*scale);
        txRectangle(x+(50)*scale,y+(-70)*scale,x+(60)*scale,y+(-80)*scale);
        txRectangle(x+(60)*scale,y+(-80)*scale,x+(80)*scale,y+(-90)*scale);
        txRectangle(x+(80)*scale,y+(-90)*scale,x+(110)*scale,y+(-100)*scale);
        txRectangle(x+(110)*scale,y+(-90)*scale,x+(160)*scale,y+(-80)*scale);
        txRectangle(x+(160)*scale,y+(-90)*scale,x+(190)*scale,y+(-100)*scale);
        txRectangle(x+(190)*scale,y+(-90)*scale,x+(210)*scale,y+(-80)*scale);
        txRectangle(x+(210)*scale,y+(-80)*scale,x+(220)*scale,y+(-70)*scale);
        txRectangle(x+(220)*scale,y+(-70)*scale,x+(230)*scale,y+(-40)*scale);
        txRectangle(x+(230)*scale,y+(-40)*scale,x+(240)*scale,y+(10)*scale);

        txSetFillColor(RGB(245,212,103));
        txFloodFill(x+(25)*scale,y+(-30)*scale);
        txFloodFill(x+(45)*scale,y+(-80)*scale);
        txFloodFill(x+(245)*scale,y+(-30)*scale);

        //����
        txSetFillColor(TX_BLACK);
        txSetColor(TX_BLACK);
        txRectangle(x+(80)*scale,y+(10)*scale,x+(130)*scale,y+(20)*scale);
        txRectangle(x+(140)*scale,y+(10)*scale,x+(180)*scale,y+(20)*scale);
        txRectangle(x+(120)*scale,y+(20)*scale,x+(130)*scale,y+(50)*scale);
        txRectangle(x+(120)*scale,y+(50)*scale,x+(130)*scale,y+(80)*scale);
        txRectangle(x+(130)*scale,y+(80)*scale,x+(150)*scale,y+(90)*scale);
        txRectangle(x+(150)*scale,y+(70)*scale,x+(160)*scale,y+(80)*scale);
        txRectangle(x+(90)*scale,y+(100)*scale,x+(170)*scale,y+(110)*scale);
        txRectangle(x+(120)*scale,y+(120)*scale,x+(140)*scale,y+(130)*scale);

        txSetFillColor(RGB(255,224,189));
        txFloodFill(x+(50)*scale,y+(0)*scale);
        txFloodFill(x+(15)*scale,y+(20)*scale);
        txFloodFill(x+(245)*scale,y+(20)*scale);
        txFloodFill(x+(25)*scale,y+(60)*scale);
        txFloodFill(x+(235)*scale,y+(60)*scale);


        txSetFillColor(RGB(141,85,36));
        txSetColor(RGB(141,85,36));
        txRectangle(x+(70)*scale,y+(-10)*scale,x+(130)*scale,y+(0)*scale);
        txRectangle(x+(140)*scale,y+(-10)*scale,x+(190)*scale,y+(0)*scale);

        txSetFillColor(RGB(224,173,105));
        txSetColor(RGB(224,173,105));
        txRectangle(x+(70)*scale,y+(20)*scale,x+(80)*scale,y+(0)*scale);
        txRectangle(x+(80)*scale,y+(0)*scale,x+(120)*scale,y+(10)*scale);
        txRectangle(x+(150)*scale,y+(0)*scale,x+(180)*scale,y+(10)*scale);
        txRectangle(x+(180)*scale,y+(0)*scale,x+(190)*scale,y+(20)*scale);

        txSetFillColor(RGB(229,201,170));
        txSetColor(RGB(229,201,170));
        txRectangle(x+(120)*scale,y+(-20)*scale,x+(130)*scale,y+(-10)*scale);
        txRectangle(x+(140)*scale,y+(-20)*scale,x+(150)*scale,y+(-10)*scale);

        txSetFillColor(RGB(201,155,94));
        txSetColor(RGB(201,155,94));
        txRectangle(x+(120)*scale,y+(0)*scale,x+(130)*scale,y+(10)*scale);
        txRectangle(x+(140)*scale,y+(0)*scale,x+(150)*scale,y+(10)*scale);

        //�����
        txSetFillColor(TX_WHITE);
        txSetColor(TX_WHITE);
        txRectangle(x+(80)*scale,y+(20)*scale,x+(120)*scale,y+(30)*scale);
        txRectangle(x+(90)*scale,y+(30)*scale,x+(110)*scale,y+(40)*scale);
        txRectangle(x+(140)*scale,y+(20)*scale,x+(180)*scale,y+(30)*scale);
        txRectangle(x+(150)*scale,y+(30)*scale,x+(170)*scale,y+(40)*scale);

        txSetFillColor(RGB(0,192,217));
        txSetColor(RGB(0,192,217));
        if(eyes == 1){
            txRectangle(x+(90)*scale,y+(20)*scale,x+(100)*scale,y+(30)*scale);
            txRectangle(x+(150)*scale,y+(20)*scale,x+(160)*scale,y+(30)*scale);
        }
        else{
            txRectangle(x+(100)*scale,y+(20)*scale,x+(110)*scale,y+(30)*scale);
            txRectangle(x+(160)*scale,y+(20)*scale,x+(170)*scale,y+(30)*scale);
        }

        //����
        txSetFillColor(TX_BLACK);
        txSetColor(TX_BLACK);
        txRectangle(x+(80)*scale,y+(140)*scale,x+(90)*scale,y+(170)*scale);
        txRectangle(x+(90)*scale,y+(170)*scale,x+(100)*scale,y+(190)*scale);
        txRectangle(x+(100)*scale,y+(160)*scale,x+(110)*scale,y+(170)*scale);
        txRectangle(x+(110)*scale,y+(150)*scale,x+(120)*scale,y+(160)*scale);
        txRectangle(x+(100)*scale,y+(190)*scale,x+(110)*scale,y+(210)*scale);
        txRectangle(x+(110)*scale,y+(210)*scale,x+(120)*scale,y+(220)*scale);
        txRectangle(x+(120)*scale,y+(220)*scale,x+(140)*scale,y+(230)*scale);
        txRectangle(x+(140)*scale,y+(210)*scale,x+(150)*scale,y+(220)*scale);
        txRectangle(x+(150)*scale,y+(190)*scale,x+(160)*scale,y+(210)*scale);
        txRectangle(x+(160)*scale,y+(170)*scale,x+(170)*scale,y+(190)*scale);
        txRectangle(x+(150)*scale,y+(160)*scale,x+(160)*scale,y+(170)*scale);
        txRectangle(x+(140)*scale,y+(150)*scale,x+(150)*scale,y+(160)*scale);
        txRectangle(x+(170)*scale,y+(140)*scale,x+(180)*scale,y+(170)*scale);
        txRectangle(x+(170)*scale,y+(170)*scale,x+(200)*scale,y+(180)*scale);
        txRectangle(x+(180)*scale,y+(180)*scale,x+(190)*scale,y+(200)*scale);
        txRectangle(x+(170)*scale,y+(200)*scale,x+(180)*scale,y+(210)*scale);
        txRectangle(x+(160)*scale,y+(210)*scale,x+(170)*scale,y+(220)*scale);
        txRectangle(x+(150)*scale,y+(220)*scale,x+(160)*scale,y+(230)*scale);
        txRectangle(x+(140)*scale,y+(230)*scale,x+(150)*scale,y+(240)*scale);
        txRectangle(x+(130)*scale,y+(240)*scale,x+(140)*scale,y+(250)*scale);
        txRectangle(x+(110)*scale,y+(230)*scale,x+(130)*scale,y+(240)*scale);
        txRectangle(x+(100)*scale,y+(220)*scale,x+(110)*scale,y+(230)*scale);
        txRectangle(x+(90)*scale,y+(210)*scale,x+(100)*scale,y+(220)*scale);
        txRectangle(x+(80)*scale,y+(200)*scale,x+(90)*scale,y+(210)*scale);
        txRectangle(x+(70)*scale,y+(180)*scale,x+(80)*scale,y+(200)*scale);
        txRectangle(x+(70)*scale,y+(170)*scale,x+(90)*scale,y+(180)*scale);
        txRectangle(x+(60)*scale,y+(150)*scale,x+(70)*scale,y+(180)*scale);
        txRectangle(x+(20)*scale,y+(140)*scale,x+(70)*scale,y+(150)*scale);
        txRectangle(x+(20)*scale,y+(150)*scale,x+(30)*scale,y+(180)*scale);
        txRectangle(x+(10)*scale,y+(180)*scale,x+(20)*scale,y+(190)*scale);
        txRectangle(x+(0)*scale,y+(190)*scale,x+(10)*scale,y+(200)*scale);
        txRectangle(x+(-10)*scale,y+(200)*scale,x+(0)*scale,y+(270)*scale);
        txRectangle(x+(-10)*scale,y+(270)*scale,x+(50)*scale,y+(280)*scale);
        txRectangle(x+(30)*scale,y+(260)*scale,x+(50)*scale,y+(270)*scale);
        txRectangle(x+(30)*scale,y+(220)*scale,x+(40)*scale,y+(260)*scale);
        txRectangle(x+(30)*scale,y+(210)*scale,x+(50)*scale,y+(220)*scale);
        txRectangle(x+(40)*scale,y+(180)*scale,x+(50)*scale,y+(210)*scale);
        txRectangle(x+(50)*scale,y+(220)*scale,x+(60)*scale,y+(260)*scale);
        txRectangle(x+(0)*scale,y+(280)*scale,x+(10)*scale,y+(310)*scale);
        txRectangle(x+(10)*scale,y+(310)*scale,x+(50)*scale,y+(320)*scale);
        txRectangle(x+(50)*scale,y+(310)*scale,x+(60)*scale,y+(280)*scale);
        txRectangle(x+(40)*scale,y+(310)*scale,x+(50)*scale,y+(340)*scale);
        txRectangle(x+(30)*scale,y+(340)*scale,x+(40)*scale,y+(360)*scale);
        txRectangle(x+(90)*scale,y+(350)*scale,x+(100)*scale,y+(320)*scale);
        txRectangle(x+(100)*scale,y+(300)*scale,x+(110)*scale,y+(320)*scale);
        txRectangle(x+(100)*scale,y+(290)*scale,x+(150)*scale,y+(300)*scale);
        txRectangle(x+(110)*scale,y+(290)*scale,x+(120)*scale,y+(230)*scale);
        txRectangle(x+(150)*scale,y+(290)*scale,x+(160)*scale,y+(320)*scale);
        txRectangle(x+(160)*scale,y+(320)*scale,x+(170)*scale,y+(350)*scale);
        txRectangle(x+(220)*scale,y+(340)*scale,x+(230)*scale,y+(360)*scale);
        txRectangle(x+(220)*scale,y+(340)*scale,x+(210)*scale,y+(310)*scale);
        txRectangle(x+(210)*scale,y+(300)*scale,x+(250)*scale,y+(310)*scale);
        txRectangle(x+(210)*scale,y+(300)*scale,x+(200)*scale,y+(270)*scale);
        txRectangle(x+(250)*scale,y+(300)*scale,x+(260)*scale,y+(270)*scale);
        txRectangle(x+(210)*scale,y+(260)*scale,x+(260)*scale,y+(270)*scale);
        txRectangle(x+(210)*scale,y+(250)*scale,x+(230)*scale,y+(260)*scale);
        txRectangle(x+(230)*scale,y+(250)*scale,x+(220)*scale,y+(200)*scale);
        txRectangle(x+(210)*scale,y+(210)*scale,x+(220)*scale,y+(180)*scale);
        txRectangle(x+(210)*scale,y+(210)*scale,x+(200)*scale,y+(250)*scale);
        txRectangle(x+(260)*scale,y+(270)*scale,x+(270)*scale,y+(200)*scale);
        txRectangle(x+(260)*scale,y+(200)*scale,x+(250)*scale,y+(180)*scale);
        txRectangle(x+(250)*scale,y+(180)*scale,x+(230)*scale,y+(170)*scale);
        txRectangle(x+(230)*scale,y+(170)*scale,x+(240)*scale,y+(150)*scale);
        txRectangle(x+(240)*scale,y+(150)*scale,x+(190)*scale,y+(140)*scale);
        txRectangle(x+(190)*scale,y+(150)*scale,x+(200)*scale,y+(170)*scale);

        txSetFillColor(RGB(255,224,189));
        txFloodFill(x+(20)*scale,y+(290)*scale);
        txFloodFill(x+(220)*scale,y+(290)*scale);

        txSetColor(TX_RED);
        txSetFillColor(TX_RED);
        txRectangle(x+(120)*scale,y+(150)*scale,x+(140)*scale,y+(220)*scale);

        txSetFillColor(TX_GRAY);
        txFloodFill(x+(75)*scale,y+(150)*scale);
        txFloodFill(x+(185)*scale,y+(150)*scale);
        txFloodFill(x+(175)*scale,y+(190)*scale);
        txFloodFill(x+(95)*scale,y+(190)*scale);
        txFloodFill(x+(105)*scale,y+(215)*scale);
        txFloodFill(x+(115)*scale,y+(225)*scale);
        txFloodFill(x+(155)*scale,y+(215)*scale);
        txFloodFill(x+(145)*scale,y+(225)*scale);
        txFloodFill(x+(135)*scale,y+(235)*scale);

        txSetFillColor(TX_WHITE);
        txFloodFill(x+(95)*scale,y+(150)*scale);
        txFloodFill(x+(165)*scale,y+(150)*scale);
        txFloodFill(x+(115)*scale,y+(180)*scale);
        txFloodFill(x+(145)*scale,y+(180)*scale);
        //����
        txSetColor(TX_BLACK);
        txSetFillColor(TX_BLACK);
        if(legs ==0){
            txRectangle(x+(20)*scale,y+(360)*scale,x+(30)*scale,y+(390)*scale);
            txRectangle(x+(0)*scale,y+(380)*scale,x+(20)*scale,y+(390)*scale);
            txRectangle(x+(-10)*scale,y+(390)*scale,x+(90)*scale,y+(410)*scale);
            txRectangle(x+(80)*scale,y+(390)*scale,x+(90)*scale,y+(350)*scale);
            txRectangle(x+(170)*scale,y+(390)*scale,x+(180)*scale,y+(350)*scale);
            txRectangle(x+(170)*scale,y+(390)*scale,x+(270)*scale,y+(410)*scale);
            txRectangle(x+(200)*scale,y+(380)*scale,x+(260)*scale,y+(390)*scale);
            txRectangle(x+(230)*scale,y+(380)*scale,x+(240)*scale,y+(360)*scale);
            txSetFillColor(TX_WHITE);
            txSetColor(TX_WHITE);
            txRectangle(x+(0)*scale,y+(390)*scale,x+(20)*scale,y+(400)*scale);
            txRectangle(x+(230)*scale,y+(390)*scale,x+(250)*scale,y+(400)*scale);
        }
        //
        txSetFillColor(TX_GRAY);
        txSetColor(TX_GRAY);
        txFloodFill(x+(90)*scale,y+(250)*scale);
        txFloodFill(x+(160)*scale,y+(250)*scale);
    }



};
