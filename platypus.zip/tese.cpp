#include <iostream>
#include "TXLib.h"
#include "main_hero.h"
#include "platypus.h"
#include "fugu.h"

using namespace std;

int main() {
	txCreateWindow(1000, 1000);
	Platypus hero(100, 500);
	//Fugu hero(100, 500);
	txSetFillColor(TX_WHITE);
	while (!GetAsyncKeyState(VK_ESCAPE)) {
		txClear();
		hero.update();
		txSleep(50);
	}
}