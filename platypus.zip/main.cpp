#include <iostream>
#include <windows.h>
#include <cstdlib>
#include "TXLib.h"
//#include "widgets.h"
#include "settings.h"
#include "functions.h"
//#include "platypus.cpp"

using namespace std;

int main() {
	txBegin();
	txCreateWindow(1920, 1080);
	//hello_window();
	//txSleep(2000);
	add_widgets();
	menu();


	while (!GetAsyncKeyState(VK_ESCAPE)) {
		update_widgets();
	}
	delete_images();
	txEnd();





}
