#include <iostream>
#include <vector>
#include "TXLib.h"
using namespace std;

class MainHero {
protected:
    int speed;
    int jump_speed;
    int x;
    int y;
    int height;
    int width;
    int jump_height = 300;
    int now_jump_height;
    bool gravity = true;
    bool jump = false;
    HDC pic;
    int i_pic = 0;
    int j_pic = 0;
    //Settings settings;
    /*int legs = 0;
    int rotation = -1;
    int eyes = 0;
    double scale = 0.5;*/
public:
    MainHero(int height, int width) {
        vector <int> leftbottom = { x, y + height };
        vector <int> lefttop = { x, y  };
        vector <int> rightbottom = { x + width, y + height };
        vector <int> righttop = { x + width, y };
    }
    virtual void move() = 0;
    virtual void draw() = 0;
    void update() {
        move();
        draw();
    }



    int get_x() {
        return x;
    }
    int get_y() {
        return y;
    }
    int get_speed() {
        return speed;
    }
    int get_height() {
        return height;
    }
    int get_width() {
        return width;
    }
    bool get_gravity() {
        return gravity;
    }

    void set_x(int x) {
        this->x = x;
    }
    void set_y(int y) {
        this->y = y;
    }
    void set_speed(int speed) {
        this->speed = speed;
    }
    void set_height(int height) {
        this->height = height;
    }
    void set_width(int width) {
        this->width = width;
    }
    void set_gravity(bool fall_down) {
        this->gravity = fall_down;
    }




    /*int get_legs() {
        return legs;
    }
    int get_rotation() {
        return rotation;
    }
    int get_eyes() {
        return eyes;
    }
    double get_scale() {
        return scale;
    }
    void set_legs(int legs) {
        this-> legs =legs;
    }
    void set_rotation(int rotation) {
        this-> rotation = rotation;
    }
    void set_eyes(int eyes) {
        this-> eyes = eyes ;
    }
    void set_scale(double scale) {
        this-> scale = scale;
    }*/

};