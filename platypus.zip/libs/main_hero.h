#include <iostream>
#include <vector>
#include "TXLib.h"
#define Main_Hero
using namespace std;
class MainHero {
protected:
    int speed;
    int jump_speed;
    int x;
    int y;
    int height;
    int width;
    int jump_height = 300;
    int now_jump_height;
    bool gravity = true;
    bool jump = false;
    HDC pic;
    int i_pic = 0;
    int j_pic = 0;

    vector <int> leftbottom;
    vector <int> lefttop;
    vector <int> rightbottom;
    vector <int> righttop;
    //Settings settings;
    /*int legs = 0;
    int rotation = -1;
    int eyes = 0;
    double scale = 0.5;*/
public:
    MainHero(int height, int width) {
        leftbottom = { x, y + height };
        lefttop = { x, y };
        rightbottom = { x + width, y + height };
        righttop = { x + width, y };
    }
   // void check_gravity();
    virtual void move() {}
    void draw();
    void update() {
        move();
        draw();
    }



    int get_x();
    int get_y();
    int get_speed();
    int get_height();
    int get_width();
    bool get_gravity();
    void set_x(int x);
    void set_y(int y);
    void set_speed(int speed);
    void set_height(int height);
    void set_width(int width);
    void set_gravity(bool fall_down);
};

//void MainHero::check_gravity() {}
void MainHero :: draw() {
    Win32::TransparentBlt(txDC(), x, y, width, height, pic, j_pic * width, i_pic * height, width, height, TX_WHITE);
}

int MainHero :: get_x() {
    return x;
}
void MainHero :: set_x(int x) {
    this->x = x;
}
int MainHero :: get_y() {
    return y;
}
void MainHero :: set_y(int y) {
    this->y = y;
}

int MainHero :: get_speed() {
    return speed;
}
void MainHero :: set_speed(int speed) {
    this->speed = speed;
}
int MainHero :: get_height() {
    return height;
}
void MainHero :: set_height(int height) {
    this->height = height;
}
int MainHero :: get_width() {
    return width;
}
void MainHero :: set_width(int width) {
    this->width = width;
}
bool MainHero :: get_gravity() {
    return gravity;
}
void MainHero :: set_gravity(bool fall_down) {
    this->gravity = fall_down;
}






