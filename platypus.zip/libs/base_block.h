#include <iostream>
#include <vector>
#define Base_Block
using namespace std;

class BaseBlock{
protected:
    int x;
    int y;
    int width;
    int height;
    HDC pic;
    vector <int> lefttop = { x, y };
    vector <int> leftbottom = { x, y + height };
    vector <int> righttop = { x + width, y };
    vector <int> rightbuttom = { x + width, y + height };
public:
    BaseBlock(int x, int y, HDC pic);
    virtual void draw() {}

    int get_x();
    void set_x(int x0);

    int get_y();
    void set_y(int y0);

    int get_width();
    void set_width(int width0);

    int get_height();
    void set_height(int height0);
};

BaseBlock :: BaseBlock(int x, int y, HDC pic) {
    this->x = x;
    this->y = y;
    this->pic = pic;
    width = 100;
    height = 100;
}

int  BaseBlock :: get_x() {
    return x;
}
void BaseBlock :: set_x(int x0) {
    x = x0;
}
int  BaseBlock :: get_y() {
    return y;
}
void BaseBlock :: set_y(int y0) {
    y = y0;
}
int  BaseBlock :: get_width() {
    return width;
}
void BaseBlock :: set_width(int width0) {
    width = width0;
}
int  BaseBlock :: get_height() {
    return height;
}
void BaseBlock :: set_height(int height0) {
    height = height0;
}

