#ifndef Base_Block
#include "base_block.h"
#endif // !base

class Block : public BaseBlock{
private:
    //int speed;
public:
    Block(int x, int y/*, int speed*/, HDC pic) : BaseBlock(x, y, pic) {}
    virtual void draw() override;
};

void Block::draw(){
    Win32::TransparentBlt(txDC(), x, y, width, height, pic, 0, 0, width, height, TX_WHITE);
}

