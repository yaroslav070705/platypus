#ifndef Base_Block
#include "base_block.h"
#endif // !base

class LavaBlock : public BaseBlock {
private:
    int speed;
public:
    LavaBlock(int x, int y, int speed, HDC pic) : BaseBlock(x, y, pic) {}
    virtual void draw() override;
};

void LavaBlock::draw() {
    Win32::TransparentBlt(txDC(), x, y, width, height, pic, 0, 0, width, height, TX_WHITE);
}
